# Changelog

## 2.2.0 - 2026-09-26

- Added the smart filter: one submitted search box whose target field is a multiple picker, so a single keyword searches several text fields at once.
- Combined the per-field conditions with `$or`: "Contains" builds `(A contains keyword) OR (B contains keyword)`, "Equals" builds `(A equals keyword) OR (B equals keyword)`. Only these two operators are offered.
- Restricted smart-filter targets to text interfaces (`input`, `textarea`, `email`, `phone`, `url`); a newly added smart filter starts from the first text field.
- V2: added a "Smart filter" entry to the quick-filter submenu; Basic settings switch the target field to a multiple picker and Value settings expose only Contains/Equals.
- V1: added a sibling "Smart filter" action-bar initializer and reused the quick-filter settings modal for the multi-field target list.
- Widened the smart-filter search box and defaulted its placeholder to "Search selected fields".
- Fixed the declaration build: cast the block resource through `unknown` (TS2352) and pass the hybrid-shell model registry entry as `any` (TS2322), so the model types resolve against either FlowEngine copy.
- Fixed the smart-filter placeholder: the V2 display step now branches on the resolved mode instead of the field interface, so “Placeholder” overrides the default “Search selected fields” hint.
- Made the search-box width configurable: “Input width” (120–800 px) was added to Display settings for text and smart filters in both V1 and V2. It replaces the hardcoded 280 px and is stored with the rest of the filter config (page schema / model props), so no server collection is involved.

- Added drag-sort: quick filters (including smart filters) can now be dragged to change their order in the action bar, and the order is persisted with the page.
- V1 keeps using the native Schema drag-sort (the `SortableItem` + draggable schema toolbar that was already rendered), so no behaviour change there.
- V2 hooks into the native FlowEngine drag-sort: the model renders itself inside flow-engine's `Droppable` (so it becomes a valid drop target) and the native `DragHandler` is registered on the quick-filter toolbar through `flowSettings.addToolbarItem`. Dropping still runs the block's own `DndProvider` → `flowEngine.moveModel` → `sortIndex` persistence.
- V2 keeps quick filters on the left (`position: 'left'`): NocoBase only wires `Droppable` + the toolbar drag handle for actions rendered on the right, so the plugin supplies the missing half. The `visible` guard is the exact complement of that branch, so a filter moved to the right group still shows a single handle.
- Registered the drag handle from both client entries, matching the existing hybrid-shell model bridge.

## 2.1.0 - 2026-09-18

- Persisted the field selected from the V2 quick-filter submenu as initialization step parameters, so newly added filters work immediately without selecting the target field again in Basic settings.

## 2.0.0 - 2026-09-17

- Added submitted text quick filters for `input`, `textarea`, `email`, `phone`, and `url` fields in V1 and V2 pages. Searches run only from the Search button or Enter.
- Added text operators and configurable placeholder/default keyword support.
- Replaced the global one-filter-per-row behavior with a per-filter “Exclusive row” setting while retaining pinned right-side actions.

## 1.1.2 - 2026-09-17

- Kept the right-side custom action group fixed on the right while quick filters stack and wrap only inside the remaining left-side space.

## 1.1.1 - 2026-09-17

- Normalized `$match`, `$notMatch`, `$anyOf`, `$noneOf`, `$in` and `$notIn` values as arrays, matching NocoBase 2.2.x filter behavior and preventing server-side `value.sort is not a function` errors.
- Preserved the selected array-field operator instead of silently rewriting `$match`/`$notMatch` to `$anyOf`/`$noneOf` when multiple selection is enabled.

## 1.1.0 - 2026-09-17

- Normalized empty, scalar and array values before rendering multi-select controls and building filters, fixing the `value.sort is not a function` crash in both V1 and V2.
- Normalized candidate values, default values, current values and filter conditions, covering single/multiple switches, empty values and fields whose interface natively supports multiple selection.
- Rendered every quick-filter object on its own action-bar row in both V1 and V2 pages, keeping the title and options horizontal and wrapping them when space is tight.

## 1.0.0 - 2026-09-12

- Initial source release.
- Added NocoBase 2.2.x compatibility metadata.
- Added V1 Schema page quick-filter initializer, settings and request-filter composition.
- Added V2 FlowEngine quick-filter action model, field submenu and filter-group composition.
- Added shared controls, option resolution, operators, Chinese/English locales and source validation.
- Enlarged select and button controls to the standard action-bar size and increased spacing.
- Registered the V2 action model from the legacy client entry for V2 pages hosted by the NocoBase 2.2.x hybrid shell.
- Preserved the V1 page schema context inside the quick-filter creation dialog so field and display-style selections work normally.
- Rendered the V1 schema toolbar around quick filters, enabling configuration, drag handling and deletion.
- Registered the V2 model in the collection action group's explicit registry so its field submenu is visible.
- Extended source verification to cover the V1 toolbar/display modes, V2 action-menu registration and package entry shims.
- Fixed the declaration build and committed the NocoBase build output (`dist`) so the plugin can be installed directly from git.
- Registered a single table action initializer and removed an unused locale key.
- Added a distributable release package (`release/*.tgz`) and a tag-driven GitHub Release workflow.
